/**
 */
package ims;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ims.Action#getSetting <em>Setting</em>}</li>
 *   <li>{@link ims.Action#getDuration <em>Duration</em>}</li>
 *   <li>{@link ims.Action#getIrrigationpumps <em>Irrigationpumps</em>}</li>
 * </ul>
 *
 * @see ims.ImsPackage#getAction()
 * @model
 * @generated
 */
public interface Action extends EObject {
	/**
	 * Returns the value of the '<em><b>Setting</b></em>' attribute list.
	 * The list contents are of type {@link ims.PumpSetting}.
	 * The literals are from the enumeration {@link ims.PumpSetting}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Setting</em>' attribute list.
	 * @see ims.PumpSetting
	 * @see ims.ImsPackage#getAction_Setting()
	 * @model upper="2"
	 * @generated
	 */
	EList<PumpSetting> getSetting();

	/**
	 * Returns the value of the '<em><b>Duration</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Duration</em>' attribute list.
	 * @see ims.ImsPackage#getAction_Duration()
	 * @model
	 * @generated
	 */
	EList<Integer> getDuration();

	/**
	 * Returns the value of the '<em><b>Irrigationpumps</b></em>' reference list.
	 * The list contents are of type {@link ims.IrrigationPump}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Irrigationpumps</em>' reference list.
	 * @see ims.ImsPackage#getAction_Irrigationpumps()
	 * @model required="true"
	 * @generated
	 */
	EList<IrrigationPump> getIrrigationpumps();

} // Action
