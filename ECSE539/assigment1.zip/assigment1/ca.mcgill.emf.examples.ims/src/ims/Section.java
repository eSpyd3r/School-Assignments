/**
 */
package ims;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Section</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ims.Section#getAssetNumber <em>Asset Number</em>}</li>
 *   <li>{@link ims.Section#getIrrigationpumps <em>Irrigationpumps</em>}</li>
 * </ul>
 *
 * @see ims.ImsPackage#getSection()
 * @model
 * @generated
 */
public interface Section extends EObject {
	/**
	 * Returns the value of the '<em><b>Asset Number</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Asset Number</em>' attribute list.
	 * @see ims.ImsPackage#getSection_AssetNumber()
	 * @model id="true" changeable="false"
	 * @generated
	 */
	EList<Integer> getAssetNumber();

	/**
	 * Returns the value of the '<em><b>Irrigationpumps</b></em>' reference list.
	 * The list contents are of type {@link ims.IrrigationPump}.
	 * It is bidirectional and its opposite is '{@link ims.IrrigationPump#getSections <em>Sections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Irrigationpumps</em>' reference list.
	 * @see ims.ImsPackage#getSection_Irrigationpumps()
	 * @see ims.IrrigationPump#getSections
	 * @model opposite="sections" required="true"
	 * @generated
	 */
	EList<IrrigationPump> getIrrigationpumps();

} // Section
