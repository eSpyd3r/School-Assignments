/**
 */
package ims.impl;

import ims.Condition;
import ims.ImsPackage;
import ims.Section;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Condition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ims.impl.ConditionImpl#getMinForecast <em>Min Forecast</em>}</li>
 *   <li>{@link ims.impl.ConditionImpl#getMaxForecast <em>Max Forecast</em>}</li>
 *   <li>{@link ims.impl.ConditionImpl#getMinMoisture <em>Min Moisture</em>}</li>
 *   <li>{@link ims.impl.ConditionImpl#getMaxMoisture <em>Max Moisture</em>}</li>
 *   <li>{@link ims.impl.ConditionImpl#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConditionImpl extends MinimalEObjectImpl.Container implements Condition {
	/**
	 * The cached value of the '{@link #getMinForecast() <em>Min Forecast</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMinForecast()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> minForecast;

	/**
	 * The cached value of the '{@link #getMaxForecast() <em>Max Forecast</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxForecast()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> maxForecast;

	/**
	 * The cached value of the '{@link #getMinMoisture() <em>Min Moisture</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMinMoisture()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> minMoisture;

	/**
	 * The cached value of the '{@link #getMaxMoisture() <em>Max Moisture</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxMoisture()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> maxMoisture;

	/**
	 * The cached value of the '{@link #getSections() <em>Sections</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSections()
	 * @generated
	 * @ordered
	 */
	protected EList<Section> sections;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConditionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ImsPackage.Literals.CONDITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getMinForecast() {
		if (minForecast == null) {
			minForecast = new EDataTypeUniqueEList<Integer>(Integer.class, this, ImsPackage.CONDITION__MIN_FORECAST);
		}
		return minForecast;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getMaxForecast() {
		if (maxForecast == null) {
			maxForecast = new EDataTypeUniqueEList<Integer>(Integer.class, this, ImsPackage.CONDITION__MAX_FORECAST);
		}
		return maxForecast;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getMinMoisture() {
		if (minMoisture == null) {
			minMoisture = new EDataTypeUniqueEList<Integer>(Integer.class, this, ImsPackage.CONDITION__MIN_MOISTURE);
		}
		return minMoisture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getMaxMoisture() {
		if (maxMoisture == null) {
			maxMoisture = new EDataTypeUniqueEList<Integer>(Integer.class, this, ImsPackage.CONDITION__MAX_MOISTURE);
		}
		return maxMoisture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Section> getSections() {
		if (sections == null) {
			sections = new EObjectResolvingEList<Section>(Section.class, this, ImsPackage.CONDITION__SECTIONS);
		}
		return sections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ImsPackage.CONDITION__MIN_FORECAST:
				return getMinForecast();
			case ImsPackage.CONDITION__MAX_FORECAST:
				return getMaxForecast();
			case ImsPackage.CONDITION__MIN_MOISTURE:
				return getMinMoisture();
			case ImsPackage.CONDITION__MAX_MOISTURE:
				return getMaxMoisture();
			case ImsPackage.CONDITION__SECTIONS:
				return getSections();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ImsPackage.CONDITION__MIN_FORECAST:
				getMinForecast().clear();
				getMinForecast().addAll((Collection<? extends Integer>)newValue);
				return;
			case ImsPackage.CONDITION__MAX_FORECAST:
				getMaxForecast().clear();
				getMaxForecast().addAll((Collection<? extends Integer>)newValue);
				return;
			case ImsPackage.CONDITION__MIN_MOISTURE:
				getMinMoisture().clear();
				getMinMoisture().addAll((Collection<? extends Integer>)newValue);
				return;
			case ImsPackage.CONDITION__MAX_MOISTURE:
				getMaxMoisture().clear();
				getMaxMoisture().addAll((Collection<? extends Integer>)newValue);
				return;
			case ImsPackage.CONDITION__SECTIONS:
				getSections().clear();
				getSections().addAll((Collection<? extends Section>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ImsPackage.CONDITION__MIN_FORECAST:
				getMinForecast().clear();
				return;
			case ImsPackage.CONDITION__MAX_FORECAST:
				getMaxForecast().clear();
				return;
			case ImsPackage.CONDITION__MIN_MOISTURE:
				getMinMoisture().clear();
				return;
			case ImsPackage.CONDITION__MAX_MOISTURE:
				getMaxMoisture().clear();
				return;
			case ImsPackage.CONDITION__SECTIONS:
				getSections().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ImsPackage.CONDITION__MIN_FORECAST:
				return minForecast != null && !minForecast.isEmpty();
			case ImsPackage.CONDITION__MAX_FORECAST:
				return maxForecast != null && !maxForecast.isEmpty();
			case ImsPackage.CONDITION__MIN_MOISTURE:
				return minMoisture != null && !minMoisture.isEmpty();
			case ImsPackage.CONDITION__MAX_MOISTURE:
				return maxMoisture != null && !maxMoisture.isEmpty();
			case ImsPackage.CONDITION__SECTIONS:
				return sections != null && !sections.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (minForecast: ");
		result.append(minForecast);
		result.append(", maxForecast: ");
		result.append(maxForecast);
		result.append(", minMoisture: ");
		result.append(minMoisture);
		result.append(", maxMoisture: ");
		result.append(maxMoisture);
		result.append(')');
		return result.toString();
	}

} //ConditionImpl
