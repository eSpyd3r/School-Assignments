/**
 */
package ims.impl;

import ims.ImsPackage;
import ims.IrrigationPump;
import ims.Section;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Section</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ims.impl.SectionImpl#getAssetNumber <em>Asset Number</em>}</li>
 *   <li>{@link ims.impl.SectionImpl#getIrrigationpumps <em>Irrigationpumps</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SectionImpl extends MinimalEObjectImpl.Container implements Section {
	/**
	 * The cached value of the '{@link #getAssetNumber() <em>Asset Number</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssetNumber()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> assetNumber;

	/**
	 * The cached value of the '{@link #getIrrigationpumps() <em>Irrigationpumps</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIrrigationpumps()
	 * @generated
	 * @ordered
	 */
	protected EList<IrrigationPump> irrigationpumps;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ImsPackage.Literals.SECTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getAssetNumber() {
		if (assetNumber == null) {
			assetNumber = new EDataTypeUniqueEList<Integer>(Integer.class, this, ImsPackage.SECTION__ASSET_NUMBER);
		}
		return assetNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<IrrigationPump> getIrrigationpumps() {
		if (irrigationpumps == null) {
			irrigationpumps = new EObjectWithInverseResolvingEList.ManyInverse<IrrigationPump>(IrrigationPump.class, this, ImsPackage.SECTION__IRRIGATIONPUMPS, ImsPackage.IRRIGATION_PUMP__SECTIONS);
		}
		return irrigationpumps;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ImsPackage.SECTION__IRRIGATIONPUMPS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getIrrigationpumps()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ImsPackage.SECTION__IRRIGATIONPUMPS:
				return ((InternalEList<?>)getIrrigationpumps()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ImsPackage.SECTION__ASSET_NUMBER:
				return getAssetNumber();
			case ImsPackage.SECTION__IRRIGATIONPUMPS:
				return getIrrigationpumps();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ImsPackage.SECTION__IRRIGATIONPUMPS:
				getIrrigationpumps().clear();
				getIrrigationpumps().addAll((Collection<? extends IrrigationPump>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ImsPackage.SECTION__IRRIGATIONPUMPS:
				getIrrigationpumps().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ImsPackage.SECTION__ASSET_NUMBER:
				return assetNumber != null && !assetNumber.isEmpty();
			case ImsPackage.SECTION__IRRIGATIONPUMPS:
				return irrigationpumps != null && !irrigationpumps.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (assetNumber: ");
		result.append(assetNumber);
		result.append(')');
		return result.toString();
	}

} //SectionImpl
