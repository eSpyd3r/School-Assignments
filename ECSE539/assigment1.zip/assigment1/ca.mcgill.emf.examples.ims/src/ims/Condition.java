/**
 */
package ims;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Condition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ims.Condition#getMinForecast <em>Min Forecast</em>}</li>
 *   <li>{@link ims.Condition#getMaxForecast <em>Max Forecast</em>}</li>
 *   <li>{@link ims.Condition#getMinMoisture <em>Min Moisture</em>}</li>
 *   <li>{@link ims.Condition#getMaxMoisture <em>Max Moisture</em>}</li>
 *   <li>{@link ims.Condition#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @see ims.ImsPackage#getCondition()
 * @model
 * @generated
 */
public interface Condition extends EObject {
	/**
	 * Returns the value of the '<em><b>Min Forecast</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Min Forecast</em>' attribute list.
	 * @see ims.ImsPackage#getCondition_MinForecast()
	 * @model
	 * @generated
	 */
	EList<Integer> getMinForecast();

	/**
	 * Returns the value of the '<em><b>Max Forecast</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Forecast</em>' attribute list.
	 * @see ims.ImsPackage#getCondition_MaxForecast()
	 * @model
	 * @generated
	 */
	EList<Integer> getMaxForecast();

	/**
	 * Returns the value of the '<em><b>Min Moisture</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Min Moisture</em>' attribute list.
	 * @see ims.ImsPackage#getCondition_MinMoisture()
	 * @model
	 * @generated
	 */
	EList<Integer> getMinMoisture();

	/**
	 * Returns the value of the '<em><b>Max Moisture</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Moisture</em>' attribute list.
	 * @see ims.ImsPackage#getCondition_MaxMoisture()
	 * @model
	 * @generated
	 */
	EList<Integer> getMaxMoisture();

	/**
	 * Returns the value of the '<em><b>Sections</b></em>' reference list.
	 * The list contents are of type {@link ims.Section}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sections</em>' reference list.
	 * @see ims.ImsPackage#getCondition_Sections()
	 * @model required="true"
	 * @generated
	 */
	EList<Section> getSections();

} // Condition
