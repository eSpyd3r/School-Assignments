/**
 */
package ims.impl;

import ims.Field;
import ims.ImsPackage;
import ims.IrrigationManagementSystem;
import ims.IrrigationPump;
import ims.IrrigationRule;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Irrigation Management System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ims.impl.IrrigationManagementSystemImpl#getIrrigationrules <em>Irrigationrules</em>}</li>
 *   <li>{@link ims.impl.IrrigationManagementSystemImpl#getFields <em>Fields</em>}</li>
 *   <li>{@link ims.impl.IrrigationManagementSystemImpl#getIrrigationpumps <em>Irrigationpumps</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IrrigationManagementSystemImpl extends MinimalEObjectImpl.Container implements IrrigationManagementSystem {
	/**
	 * The cached value of the '{@link #getIrrigationrules() <em>Irrigationrules</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIrrigationrules()
	 * @generated
	 * @ordered
	 */
	protected EList<IrrigationRule> irrigationrules;

	/**
	 * The cached value of the '{@link #getFields() <em>Fields</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFields()
	 * @generated
	 * @ordered
	 */
	protected EList<Field> fields;

	/**
	 * The cached value of the '{@link #getIrrigationpumps() <em>Irrigationpumps</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIrrigationpumps()
	 * @generated
	 * @ordered
	 */
	protected EList<IrrigationPump> irrigationpumps;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IrrigationManagementSystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ImsPackage.Literals.IRRIGATION_MANAGEMENT_SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<IrrigationRule> getIrrigationrules() {
		if (irrigationrules == null) {
			irrigationrules = new EObjectContainmentEList<IrrigationRule>(IrrigationRule.class, this, ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONRULES);
		}
		return irrigationrules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Field> getFields() {
		if (fields == null) {
			fields = new EObjectContainmentEList<Field>(Field.class, this, ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__FIELDS);
		}
		return fields;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<IrrigationPump> getIrrigationpumps() {
		if (irrigationpumps == null) {
			irrigationpumps = new EObjectContainmentEList<IrrigationPump>(IrrigationPump.class, this, ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONPUMPS);
		}
		return irrigationpumps;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONRULES:
				return ((InternalEList<?>)getIrrigationrules()).basicRemove(otherEnd, msgs);
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__FIELDS:
				return ((InternalEList<?>)getFields()).basicRemove(otherEnd, msgs);
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONPUMPS:
				return ((InternalEList<?>)getIrrigationpumps()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONRULES:
				return getIrrigationrules();
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__FIELDS:
				return getFields();
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONPUMPS:
				return getIrrigationpumps();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONRULES:
				getIrrigationrules().clear();
				getIrrigationrules().addAll((Collection<? extends IrrigationRule>)newValue);
				return;
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__FIELDS:
				getFields().clear();
				getFields().addAll((Collection<? extends Field>)newValue);
				return;
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONPUMPS:
				getIrrigationpumps().clear();
				getIrrigationpumps().addAll((Collection<? extends IrrigationPump>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONRULES:
				getIrrigationrules().clear();
				return;
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__FIELDS:
				getFields().clear();
				return;
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONPUMPS:
				getIrrigationpumps().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONRULES:
				return irrigationrules != null && !irrigationrules.isEmpty();
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__FIELDS:
				return fields != null && !fields.isEmpty();
			case ImsPackage.IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONPUMPS:
				return irrigationpumps != null && !irrigationpumps.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //IrrigationManagementSystemImpl
