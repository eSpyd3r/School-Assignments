/**
 */
package ims.impl;

import ims.Field;
import ims.ImsPackage;
import ims.Section;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Field</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ims.impl.FieldImpl#getAssetNumber <em>Asset Number</em>}</li>
 *   <li>{@link ims.impl.FieldImpl#getMoistureLevel <em>Moisture Level</em>}</li>
 *   <li>{@link ims.impl.FieldImpl#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FieldImpl extends MinimalEObjectImpl.Container implements Field {
	/**
	 * The cached value of the '{@link #getAssetNumber() <em>Asset Number</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssetNumber()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> assetNumber;

	/**
	 * The cached value of the '{@link #getMoistureLevel() <em>Moisture Level</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMoistureLevel()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> moistureLevel;

	/**
	 * The cached value of the '{@link #getSections() <em>Sections</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSections()
	 * @generated
	 * @ordered
	 */
	protected EList<Section> sections;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FieldImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ImsPackage.Literals.FIELD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getAssetNumber() {
		if (assetNumber == null) {
			assetNumber = new EDataTypeUniqueEList<Integer>(Integer.class, this, ImsPackage.FIELD__ASSET_NUMBER);
		}
		return assetNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getMoistureLevel() {
		if (moistureLevel == null) {
			moistureLevel = new EDataTypeUniqueEList<Integer>(Integer.class, this, ImsPackage.FIELD__MOISTURE_LEVEL);
		}
		return moistureLevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Section> getSections() {
		if (sections == null) {
			sections = new EObjectContainmentEList<Section>(Section.class, this, ImsPackage.FIELD__SECTIONS);
		}
		return sections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ImsPackage.FIELD__SECTIONS:
				return ((InternalEList<?>)getSections()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ImsPackage.FIELD__ASSET_NUMBER:
				return getAssetNumber();
			case ImsPackage.FIELD__MOISTURE_LEVEL:
				return getMoistureLevel();
			case ImsPackage.FIELD__SECTIONS:
				return getSections();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ImsPackage.FIELD__MOISTURE_LEVEL:
				getMoistureLevel().clear();
				getMoistureLevel().addAll((Collection<? extends Integer>)newValue);
				return;
			case ImsPackage.FIELD__SECTIONS:
				getSections().clear();
				getSections().addAll((Collection<? extends Section>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ImsPackage.FIELD__MOISTURE_LEVEL:
				getMoistureLevel().clear();
				return;
			case ImsPackage.FIELD__SECTIONS:
				getSections().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ImsPackage.FIELD__ASSET_NUMBER:
				return assetNumber != null && !assetNumber.isEmpty();
			case ImsPackage.FIELD__MOISTURE_LEVEL:
				return moistureLevel != null && !moistureLevel.isEmpty();
			case ImsPackage.FIELD__SECTIONS:
				return sections != null && !sections.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (assetNumber: ");
		result.append(assetNumber);
		result.append(", moistureLevel: ");
		result.append(moistureLevel);
		result.append(')');
		return result.toString();
	}

} //FieldImpl
