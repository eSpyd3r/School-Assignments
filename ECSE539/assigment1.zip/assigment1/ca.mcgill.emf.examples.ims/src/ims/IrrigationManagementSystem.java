/**
 */
package ims;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Irrigation Management System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ims.IrrigationManagementSystem#getIrrigationrules <em>Irrigationrules</em>}</li>
 *   <li>{@link ims.IrrigationManagementSystem#getFields <em>Fields</em>}</li>
 *   <li>{@link ims.IrrigationManagementSystem#getIrrigationpumps <em>Irrigationpumps</em>}</li>
 * </ul>
 *
 * @see ims.ImsPackage#getIrrigationManagementSystem()
 * @model
 * @generated
 */
public interface IrrigationManagementSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Irrigationrules</b></em>' containment reference list.
	 * The list contents are of type {@link ims.IrrigationRule}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Irrigationrules</em>' containment reference list.
	 * @see ims.ImsPackage#getIrrigationManagementSystem_Irrigationrules()
	 * @model containment="true"
	 * @generated
	 */
	EList<IrrigationRule> getIrrigationrules();

	/**
	 * Returns the value of the '<em><b>Fields</b></em>' containment reference list.
	 * The list contents are of type {@link ims.Field}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fields</em>' containment reference list.
	 * @see ims.ImsPackage#getIrrigationManagementSystem_Fields()
	 * @model containment="true"
	 * @generated
	 */
	EList<Field> getFields();

	/**
	 * Returns the value of the '<em><b>Irrigationpumps</b></em>' containment reference list.
	 * The list contents are of type {@link ims.IrrigationPump}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Irrigationpumps</em>' containment reference list.
	 * @see ims.ImsPackage#getIrrigationManagementSystem_Irrigationpumps()
	 * @model containment="true"
	 * @generated
	 */
	EList<IrrigationPump> getIrrigationpumps();

} // IrrigationManagementSystem
