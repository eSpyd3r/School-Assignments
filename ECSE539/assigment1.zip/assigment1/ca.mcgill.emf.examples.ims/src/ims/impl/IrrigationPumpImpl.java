/**
 */
package ims.impl;

import ims.ImsPackage;
import ims.IrrigationPump;
import ims.PumpSetting;
import ims.Section;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Irrigation Pump</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ims.impl.IrrigationPumpImpl#getAssetNumber <em>Asset Number</em>}</li>
 *   <li>{@link ims.impl.IrrigationPumpImpl#getSetting <em>Setting</em>}</li>
 *   <li>{@link ims.impl.IrrigationPumpImpl#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IrrigationPumpImpl extends MinimalEObjectImpl.Container implements IrrigationPump {
	/**
	 * The default value of the '{@link #getAssetNumber() <em>Asset Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssetNumber()
	 * @generated
	 * @ordered
	 */
	protected static final int ASSET_NUMBER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getAssetNumber() <em>Asset Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssetNumber()
	 * @generated
	 * @ordered
	 */
	protected int assetNumber = ASSET_NUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSetting() <em>Setting</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSetting()
	 * @generated
	 * @ordered
	 */
	protected EList<PumpSetting> setting;

	/**
	 * The cached value of the '{@link #getSections() <em>Sections</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSections()
	 * @generated
	 * @ordered
	 */
	protected EList<Section> sections;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IrrigationPumpImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ImsPackage.Literals.IRRIGATION_PUMP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getAssetNumber() {
		return assetNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PumpSetting> getSetting() {
		if (setting == null) {
			setting = new EDataTypeUniqueEList<PumpSetting>(PumpSetting.class, this, ImsPackage.IRRIGATION_PUMP__SETTING);
		}
		return setting;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Section> getSections() {
		if (sections == null) {
			sections = new EObjectWithInverseResolvingEList.ManyInverse<Section>(Section.class, this, ImsPackage.IRRIGATION_PUMP__SECTIONS, ImsPackage.SECTION__IRRIGATIONPUMPS);
		}
		return sections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_PUMP__SECTIONS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getSections()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_PUMP__SECTIONS:
				return ((InternalEList<?>)getSections()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_PUMP__ASSET_NUMBER:
				return getAssetNumber();
			case ImsPackage.IRRIGATION_PUMP__SETTING:
				return getSetting();
			case ImsPackage.IRRIGATION_PUMP__SECTIONS:
				return getSections();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_PUMP__SETTING:
				getSetting().clear();
				getSetting().addAll((Collection<? extends PumpSetting>)newValue);
				return;
			case ImsPackage.IRRIGATION_PUMP__SECTIONS:
				getSections().clear();
				getSections().addAll((Collection<? extends Section>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_PUMP__SETTING:
				getSetting().clear();
				return;
			case ImsPackage.IRRIGATION_PUMP__SECTIONS:
				getSections().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ImsPackage.IRRIGATION_PUMP__ASSET_NUMBER:
				return assetNumber != ASSET_NUMBER_EDEFAULT;
			case ImsPackage.IRRIGATION_PUMP__SETTING:
				return setting != null && !setting.isEmpty();
			case ImsPackage.IRRIGATION_PUMP__SECTIONS:
				return sections != null && !sections.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (assetNumber: ");
		result.append(assetNumber);
		result.append(", setting: ");
		result.append(setting);
		result.append(')');
		return result.toString();
	}

} //IrrigationPumpImpl
