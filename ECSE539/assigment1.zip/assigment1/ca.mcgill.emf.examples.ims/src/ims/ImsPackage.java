/**
 */
package ims;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see ims.ImsFactory
 * @model kind="package"
 * @generated
 */
public interface ImsPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "ims";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://mcgill.ca/examples/ims";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "ims";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ImsPackage eINSTANCE = ims.impl.ImsPackageImpl.init();

	/**
	 * The meta object id for the '{@link ims.impl.IrrigationManagementSystemImpl <em>Irrigation Management System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ims.impl.IrrigationManagementSystemImpl
	 * @see ims.impl.ImsPackageImpl#getIrrigationManagementSystem()
	 * @generated
	 */
	int IRRIGATION_MANAGEMENT_SYSTEM = 0;

	/**
	 * The feature id for the '<em><b>Irrigationrules</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONRULES = 0;

	/**
	 * The feature id for the '<em><b>Fields</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_MANAGEMENT_SYSTEM__FIELDS = 1;

	/**
	 * The feature id for the '<em><b>Irrigationpumps</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONPUMPS = 2;

	/**
	 * The number of structural features of the '<em>Irrigation Management System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_MANAGEMENT_SYSTEM_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Irrigation Management System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_MANAGEMENT_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ims.impl.IrrigationRuleImpl <em>Irrigation Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ims.impl.IrrigationRuleImpl
	 * @see ims.impl.ImsPackageImpl#getIrrigationRule()
	 * @generated
	 */
	int IRRIGATION_RULE = 1;

	/**
	 * The feature id for the '<em><b>Conditions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_RULE__CONDITIONS = 0;

	/**
	 * The feature id for the '<em><b>Actions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_RULE__ACTIONS = 1;

	/**
	 * The number of structural features of the '<em>Irrigation Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_RULE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Irrigation Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_RULE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ims.impl.FieldImpl <em>Field</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ims.impl.FieldImpl
	 * @see ims.impl.ImsPackageImpl#getField()
	 * @generated
	 */
	int FIELD = 2;

	/**
	 * The feature id for the '<em><b>Asset Number</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD__ASSET_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Moisture Level</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD__MOISTURE_LEVEL = 1;

	/**
	 * The feature id for the '<em><b>Sections</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD__SECTIONS = 2;

	/**
	 * The number of structural features of the '<em>Field</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Field</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ims.impl.SectionImpl <em>Section</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ims.impl.SectionImpl
	 * @see ims.impl.ImsPackageImpl#getSection()
	 * @generated
	 */
	int SECTION = 3;

	/**
	 * The feature id for the '<em><b>Asset Number</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTION__ASSET_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Irrigationpumps</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTION__IRRIGATIONPUMPS = 1;

	/**
	 * The number of structural features of the '<em>Section</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Section</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ims.impl.IrrigationPumpImpl <em>Irrigation Pump</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ims.impl.IrrigationPumpImpl
	 * @see ims.impl.ImsPackageImpl#getIrrigationPump()
	 * @generated
	 */
	int IRRIGATION_PUMP = 4;

	/**
	 * The feature id for the '<em><b>Asset Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_PUMP__ASSET_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Setting</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_PUMP__SETTING = 1;

	/**
	 * The feature id for the '<em><b>Sections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_PUMP__SECTIONS = 2;

	/**
	 * The number of structural features of the '<em>Irrigation Pump</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_PUMP_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Irrigation Pump</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IRRIGATION_PUMP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ims.impl.ConditionImpl <em>Condition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ims.impl.ConditionImpl
	 * @see ims.impl.ImsPackageImpl#getCondition()
	 * @generated
	 */
	int CONDITION = 5;

	/**
	 * The feature id for the '<em><b>Min Forecast</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__MIN_FORECAST = 0;

	/**
	 * The feature id for the '<em><b>Max Forecast</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__MAX_FORECAST = 1;

	/**
	 * The feature id for the '<em><b>Min Moisture</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__MIN_MOISTURE = 2;

	/**
	 * The feature id for the '<em><b>Max Moisture</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__MAX_MOISTURE = 3;

	/**
	 * The feature id for the '<em><b>Sections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__SECTIONS = 4;

	/**
	 * The number of structural features of the '<em>Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ims.impl.ActionImpl <em>Action</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ims.impl.ActionImpl
	 * @see ims.impl.ImsPackageImpl#getAction()
	 * @generated
	 */
	int ACTION = 6;

	/**
	 * The feature id for the '<em><b>Setting</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION__SETTING = 0;

	/**
	 * The feature id for the '<em><b>Duration</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION__DURATION = 1;

	/**
	 * The feature id for the '<em><b>Irrigationpumps</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION__IRRIGATIONPUMPS = 2;

	/**
	 * The number of structural features of the '<em>Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ims.PumpSetting <em>Pump Setting</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ims.PumpSetting
	 * @see ims.impl.ImsPackageImpl#getPumpSetting()
	 * @generated
	 */
	int PUMP_SETTING = 7;


	/**
	 * Returns the meta object for class '{@link ims.IrrigationManagementSystem <em>Irrigation Management System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Irrigation Management System</em>'.
	 * @see ims.IrrigationManagementSystem
	 * @generated
	 */
	EClass getIrrigationManagementSystem();

	/**
	 * Returns the meta object for the containment reference list '{@link ims.IrrigationManagementSystem#getIrrigationrules <em>Irrigationrules</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Irrigationrules</em>'.
	 * @see ims.IrrigationManagementSystem#getIrrigationrules()
	 * @see #getIrrigationManagementSystem()
	 * @generated
	 */
	EReference getIrrigationManagementSystem_Irrigationrules();

	/**
	 * Returns the meta object for the containment reference list '{@link ims.IrrigationManagementSystem#getFields <em>Fields</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fields</em>'.
	 * @see ims.IrrigationManagementSystem#getFields()
	 * @see #getIrrigationManagementSystem()
	 * @generated
	 */
	EReference getIrrigationManagementSystem_Fields();

	/**
	 * Returns the meta object for the containment reference list '{@link ims.IrrigationManagementSystem#getIrrigationpumps <em>Irrigationpumps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Irrigationpumps</em>'.
	 * @see ims.IrrigationManagementSystem#getIrrigationpumps()
	 * @see #getIrrigationManagementSystem()
	 * @generated
	 */
	EReference getIrrigationManagementSystem_Irrigationpumps();

	/**
	 * Returns the meta object for class '{@link ims.IrrigationRule <em>Irrigation Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Irrigation Rule</em>'.
	 * @see ims.IrrigationRule
	 * @generated
	 */
	EClass getIrrigationRule();

	/**
	 * Returns the meta object for the containment reference list '{@link ims.IrrigationRule#getConditions <em>Conditions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Conditions</em>'.
	 * @see ims.IrrigationRule#getConditions()
	 * @see #getIrrigationRule()
	 * @generated
	 */
	EReference getIrrigationRule_Conditions();

	/**
	 * Returns the meta object for the containment reference list '{@link ims.IrrigationRule#getActions <em>Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Actions</em>'.
	 * @see ims.IrrigationRule#getActions()
	 * @see #getIrrigationRule()
	 * @generated
	 */
	EReference getIrrigationRule_Actions();

	/**
	 * Returns the meta object for class '{@link ims.Field <em>Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Field</em>'.
	 * @see ims.Field
	 * @generated
	 */
	EClass getField();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Field#getAssetNumber <em>Asset Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Asset Number</em>'.
	 * @see ims.Field#getAssetNumber()
	 * @see #getField()
	 * @generated
	 */
	EAttribute getField_AssetNumber();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Field#getMoistureLevel <em>Moisture Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Moisture Level</em>'.
	 * @see ims.Field#getMoistureLevel()
	 * @see #getField()
	 * @generated
	 */
	EAttribute getField_MoistureLevel();

	/**
	 * Returns the meta object for the containment reference list '{@link ims.Field#getSections <em>Sections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sections</em>'.
	 * @see ims.Field#getSections()
	 * @see #getField()
	 * @generated
	 */
	EReference getField_Sections();

	/**
	 * Returns the meta object for class '{@link ims.Section <em>Section</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Section</em>'.
	 * @see ims.Section
	 * @generated
	 */
	EClass getSection();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Section#getAssetNumber <em>Asset Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Asset Number</em>'.
	 * @see ims.Section#getAssetNumber()
	 * @see #getSection()
	 * @generated
	 */
	EAttribute getSection_AssetNumber();

	/**
	 * Returns the meta object for the reference list '{@link ims.Section#getIrrigationpumps <em>Irrigationpumps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Irrigationpumps</em>'.
	 * @see ims.Section#getIrrigationpumps()
	 * @see #getSection()
	 * @generated
	 */
	EReference getSection_Irrigationpumps();

	/**
	 * Returns the meta object for class '{@link ims.IrrigationPump <em>Irrigation Pump</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Irrigation Pump</em>'.
	 * @see ims.IrrigationPump
	 * @generated
	 */
	EClass getIrrigationPump();

	/**
	 * Returns the meta object for the attribute '{@link ims.IrrigationPump#getAssetNumber <em>Asset Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Asset Number</em>'.
	 * @see ims.IrrigationPump#getAssetNumber()
	 * @see #getIrrigationPump()
	 * @generated
	 */
	EAttribute getIrrigationPump_AssetNumber();

	/**
	 * Returns the meta object for the attribute list '{@link ims.IrrigationPump#getSetting <em>Setting</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Setting</em>'.
	 * @see ims.IrrigationPump#getSetting()
	 * @see #getIrrigationPump()
	 * @generated
	 */
	EAttribute getIrrigationPump_Setting();

	/**
	 * Returns the meta object for the reference list '{@link ims.IrrigationPump#getSections <em>Sections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sections</em>'.
	 * @see ims.IrrigationPump#getSections()
	 * @see #getIrrigationPump()
	 * @generated
	 */
	EReference getIrrigationPump_Sections();

	/**
	 * Returns the meta object for class '{@link ims.Condition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Condition</em>'.
	 * @see ims.Condition
	 * @generated
	 */
	EClass getCondition();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Condition#getMinForecast <em>Min Forecast</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Min Forecast</em>'.
	 * @see ims.Condition#getMinForecast()
	 * @see #getCondition()
	 * @generated
	 */
	EAttribute getCondition_MinForecast();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Condition#getMaxForecast <em>Max Forecast</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Max Forecast</em>'.
	 * @see ims.Condition#getMaxForecast()
	 * @see #getCondition()
	 * @generated
	 */
	EAttribute getCondition_MaxForecast();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Condition#getMinMoisture <em>Min Moisture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Min Moisture</em>'.
	 * @see ims.Condition#getMinMoisture()
	 * @see #getCondition()
	 * @generated
	 */
	EAttribute getCondition_MinMoisture();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Condition#getMaxMoisture <em>Max Moisture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Max Moisture</em>'.
	 * @see ims.Condition#getMaxMoisture()
	 * @see #getCondition()
	 * @generated
	 */
	EAttribute getCondition_MaxMoisture();

	/**
	 * Returns the meta object for the reference list '{@link ims.Condition#getSections <em>Sections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sections</em>'.
	 * @see ims.Condition#getSections()
	 * @see #getCondition()
	 * @generated
	 */
	EReference getCondition_Sections();

	/**
	 * Returns the meta object for class '{@link ims.Action <em>Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Action</em>'.
	 * @see ims.Action
	 * @generated
	 */
	EClass getAction();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Action#getSetting <em>Setting</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Setting</em>'.
	 * @see ims.Action#getSetting()
	 * @see #getAction()
	 * @generated
	 */
	EAttribute getAction_Setting();

	/**
	 * Returns the meta object for the attribute list '{@link ims.Action#getDuration <em>Duration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Duration</em>'.
	 * @see ims.Action#getDuration()
	 * @see #getAction()
	 * @generated
	 */
	EAttribute getAction_Duration();

	/**
	 * Returns the meta object for the reference list '{@link ims.Action#getIrrigationpumps <em>Irrigationpumps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Irrigationpumps</em>'.
	 * @see ims.Action#getIrrigationpumps()
	 * @see #getAction()
	 * @generated
	 */
	EReference getAction_Irrigationpumps();

	/**
	 * Returns the meta object for enum '{@link ims.PumpSetting <em>Pump Setting</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Pump Setting</em>'.
	 * @see ims.PumpSetting
	 * @generated
	 */
	EEnum getPumpSetting();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ImsFactory getImsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link ims.impl.IrrigationManagementSystemImpl <em>Irrigation Management System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ims.impl.IrrigationManagementSystemImpl
		 * @see ims.impl.ImsPackageImpl#getIrrigationManagementSystem()
		 * @generated
		 */
		EClass IRRIGATION_MANAGEMENT_SYSTEM = eINSTANCE.getIrrigationManagementSystem();

		/**
		 * The meta object literal for the '<em><b>Irrigationrules</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONRULES = eINSTANCE.getIrrigationManagementSystem_Irrigationrules();

		/**
		 * The meta object literal for the '<em><b>Fields</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IRRIGATION_MANAGEMENT_SYSTEM__FIELDS = eINSTANCE.getIrrigationManagementSystem_Fields();

		/**
		 * The meta object literal for the '<em><b>Irrigationpumps</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IRRIGATION_MANAGEMENT_SYSTEM__IRRIGATIONPUMPS = eINSTANCE.getIrrigationManagementSystem_Irrigationpumps();

		/**
		 * The meta object literal for the '{@link ims.impl.IrrigationRuleImpl <em>Irrigation Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ims.impl.IrrigationRuleImpl
		 * @see ims.impl.ImsPackageImpl#getIrrigationRule()
		 * @generated
		 */
		EClass IRRIGATION_RULE = eINSTANCE.getIrrigationRule();

		/**
		 * The meta object literal for the '<em><b>Conditions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IRRIGATION_RULE__CONDITIONS = eINSTANCE.getIrrigationRule_Conditions();

		/**
		 * The meta object literal for the '<em><b>Actions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IRRIGATION_RULE__ACTIONS = eINSTANCE.getIrrigationRule_Actions();

		/**
		 * The meta object literal for the '{@link ims.impl.FieldImpl <em>Field</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ims.impl.FieldImpl
		 * @see ims.impl.ImsPackageImpl#getField()
		 * @generated
		 */
		EClass FIELD = eINSTANCE.getField();

		/**
		 * The meta object literal for the '<em><b>Asset Number</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD__ASSET_NUMBER = eINSTANCE.getField_AssetNumber();

		/**
		 * The meta object literal for the '<em><b>Moisture Level</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD__MOISTURE_LEVEL = eINSTANCE.getField_MoistureLevel();

		/**
		 * The meta object literal for the '<em><b>Sections</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIELD__SECTIONS = eINSTANCE.getField_Sections();

		/**
		 * The meta object literal for the '{@link ims.impl.SectionImpl <em>Section</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ims.impl.SectionImpl
		 * @see ims.impl.ImsPackageImpl#getSection()
		 * @generated
		 */
		EClass SECTION = eINSTANCE.getSection();

		/**
		 * The meta object literal for the '<em><b>Asset Number</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTION__ASSET_NUMBER = eINSTANCE.getSection_AssetNumber();

		/**
		 * The meta object literal for the '<em><b>Irrigationpumps</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTION__IRRIGATIONPUMPS = eINSTANCE.getSection_Irrigationpumps();

		/**
		 * The meta object literal for the '{@link ims.impl.IrrigationPumpImpl <em>Irrigation Pump</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ims.impl.IrrigationPumpImpl
		 * @see ims.impl.ImsPackageImpl#getIrrigationPump()
		 * @generated
		 */
		EClass IRRIGATION_PUMP = eINSTANCE.getIrrigationPump();

		/**
		 * The meta object literal for the '<em><b>Asset Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IRRIGATION_PUMP__ASSET_NUMBER = eINSTANCE.getIrrigationPump_AssetNumber();

		/**
		 * The meta object literal for the '<em><b>Setting</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IRRIGATION_PUMP__SETTING = eINSTANCE.getIrrigationPump_Setting();

		/**
		 * The meta object literal for the '<em><b>Sections</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IRRIGATION_PUMP__SECTIONS = eINSTANCE.getIrrigationPump_Sections();

		/**
		 * The meta object literal for the '{@link ims.impl.ConditionImpl <em>Condition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ims.impl.ConditionImpl
		 * @see ims.impl.ImsPackageImpl#getCondition()
		 * @generated
		 */
		EClass CONDITION = eINSTANCE.getCondition();

		/**
		 * The meta object literal for the '<em><b>Min Forecast</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONDITION__MIN_FORECAST = eINSTANCE.getCondition_MinForecast();

		/**
		 * The meta object literal for the '<em><b>Max Forecast</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONDITION__MAX_FORECAST = eINSTANCE.getCondition_MaxForecast();

		/**
		 * The meta object literal for the '<em><b>Min Moisture</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONDITION__MIN_MOISTURE = eINSTANCE.getCondition_MinMoisture();

		/**
		 * The meta object literal for the '<em><b>Max Moisture</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONDITION__MAX_MOISTURE = eINSTANCE.getCondition_MaxMoisture();

		/**
		 * The meta object literal for the '<em><b>Sections</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONDITION__SECTIONS = eINSTANCE.getCondition_Sections();

		/**
		 * The meta object literal for the '{@link ims.impl.ActionImpl <em>Action</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ims.impl.ActionImpl
		 * @see ims.impl.ImsPackageImpl#getAction()
		 * @generated
		 */
		EClass ACTION = eINSTANCE.getAction();

		/**
		 * The meta object literal for the '<em><b>Setting</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTION__SETTING = eINSTANCE.getAction_Setting();

		/**
		 * The meta object literal for the '<em><b>Duration</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTION__DURATION = eINSTANCE.getAction_Duration();

		/**
		 * The meta object literal for the '<em><b>Irrigationpumps</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTION__IRRIGATIONPUMPS = eINSTANCE.getAction_Irrigationpumps();

		/**
		 * The meta object literal for the '{@link ims.PumpSetting <em>Pump Setting</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ims.PumpSetting
		 * @see ims.impl.ImsPackageImpl#getPumpSetting()
		 * @generated
		 */
		EEnum PUMP_SETTING = eINSTANCE.getPumpSetting();

	}

} //ImsPackage
