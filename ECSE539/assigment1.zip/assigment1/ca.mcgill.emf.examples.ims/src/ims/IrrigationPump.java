/**
 */
package ims;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Irrigation Pump</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ims.IrrigationPump#getAssetNumber <em>Asset Number</em>}</li>
 *   <li>{@link ims.IrrigationPump#getSetting <em>Setting</em>}</li>
 *   <li>{@link ims.IrrigationPump#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @see ims.ImsPackage#getIrrigationPump()
 * @model
 * @generated
 */
public interface IrrigationPump extends EObject {
	/**
	 * Returns the value of the '<em><b>Asset Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Asset Number</em>' attribute.
	 * @see ims.ImsPackage#getIrrigationPump_AssetNumber()
	 * @model id="true" changeable="false"
	 * @generated
	 */
	int getAssetNumber();

	/**
	 * Returns the value of the '<em><b>Setting</b></em>' attribute list.
	 * The list contents are of type {@link ims.PumpSetting}.
	 * The literals are from the enumeration {@link ims.PumpSetting}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Setting</em>' attribute list.
	 * @see ims.PumpSetting
	 * @see ims.ImsPackage#getIrrigationPump_Setting()
	 * @model upper="2"
	 * @generated
	 */
	EList<PumpSetting> getSetting();

	/**
	 * Returns the value of the '<em><b>Sections</b></em>' reference list.
	 * The list contents are of type {@link ims.Section}.
	 * It is bidirectional and its opposite is '{@link ims.Section#getIrrigationpumps <em>Irrigationpumps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sections</em>' reference list.
	 * @see ims.ImsPackage#getIrrigationPump_Sections()
	 * @see ims.Section#getIrrigationpumps
	 * @model opposite="irrigationpumps" required="true"
	 * @generated
	 */
	EList<Section> getSections();

} // IrrigationPump
