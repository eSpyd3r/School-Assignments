/**
 */
package ims.impl;

import ims.Action;
import ims.ImsPackage;
import ims.IrrigationPump;
import ims.PumpSetting;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Action</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link ims.impl.ActionImpl#getSetting <em>Setting</em>}</li>
 *   <li>{@link ims.impl.ActionImpl#getDuration <em>Duration</em>}</li>
 *   <li>{@link ims.impl.ActionImpl#getIrrigationpumps <em>Irrigationpumps</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ActionImpl extends MinimalEObjectImpl.Container implements Action {
	/**
	 * The cached value of the '{@link #getSetting() <em>Setting</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSetting()
	 * @generated
	 * @ordered
	 */
	protected EList<PumpSetting> setting;

	/**
	 * The cached value of the '{@link #getDuration() <em>Duration</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDuration()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> duration;

	/**
	 * The cached value of the '{@link #getIrrigationpumps() <em>Irrigationpumps</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIrrigationpumps()
	 * @generated
	 * @ordered
	 */
	protected EList<IrrigationPump> irrigationpumps;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ImsPackage.Literals.ACTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PumpSetting> getSetting() {
		if (setting == null) {
			setting = new EDataTypeUniqueEList<PumpSetting>(PumpSetting.class, this, ImsPackage.ACTION__SETTING);
		}
		return setting;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getDuration() {
		if (duration == null) {
			duration = new EDataTypeUniqueEList<Integer>(Integer.class, this, ImsPackage.ACTION__DURATION);
		}
		return duration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<IrrigationPump> getIrrigationpumps() {
		if (irrigationpumps == null) {
			irrigationpumps = new EObjectResolvingEList<IrrigationPump>(IrrigationPump.class, this, ImsPackage.ACTION__IRRIGATIONPUMPS);
		}
		return irrigationpumps;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ImsPackage.ACTION__SETTING:
				return getSetting();
			case ImsPackage.ACTION__DURATION:
				return getDuration();
			case ImsPackage.ACTION__IRRIGATIONPUMPS:
				return getIrrigationpumps();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ImsPackage.ACTION__SETTING:
				getSetting().clear();
				getSetting().addAll((Collection<? extends PumpSetting>)newValue);
				return;
			case ImsPackage.ACTION__DURATION:
				getDuration().clear();
				getDuration().addAll((Collection<? extends Integer>)newValue);
				return;
			case ImsPackage.ACTION__IRRIGATIONPUMPS:
				getIrrigationpumps().clear();
				getIrrigationpumps().addAll((Collection<? extends IrrigationPump>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ImsPackage.ACTION__SETTING:
				getSetting().clear();
				return;
			case ImsPackage.ACTION__DURATION:
				getDuration().clear();
				return;
			case ImsPackage.ACTION__IRRIGATIONPUMPS:
				getIrrigationpumps().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ImsPackage.ACTION__SETTING:
				return setting != null && !setting.isEmpty();
			case ImsPackage.ACTION__DURATION:
				return duration != null && !duration.isEmpty();
			case ImsPackage.ACTION__IRRIGATIONPUMPS:
				return irrigationpumps != null && !irrigationpumps.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (setting: ");
		result.append(setting);
		result.append(", duration: ");
		result.append(duration);
		result.append(')');
		return result.toString();
	}

} //ActionImpl
