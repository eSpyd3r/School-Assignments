/**
 */
package ims;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Field</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link ims.Field#getAssetNumber <em>Asset Number</em>}</li>
 *   <li>{@link ims.Field#getMoistureLevel <em>Moisture Level</em>}</li>
 *   <li>{@link ims.Field#getSections <em>Sections</em>}</li>
 * </ul>
 *
 * @see ims.ImsPackage#getField()
 * @model
 * @generated
 */
public interface Field extends EObject {
	/**
	 * Returns the value of the '<em><b>Asset Number</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Asset Number</em>' attribute list.
	 * @see ims.ImsPackage#getField_AssetNumber()
	 * @model id="true" changeable="false"
	 * @generated
	 */
	EList<Integer> getAssetNumber();

	/**
	 * Returns the value of the '<em><b>Moisture Level</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Moisture Level</em>' attribute list.
	 * @see ims.ImsPackage#getField_MoistureLevel()
	 * @model upper="100"
	 * @generated
	 */
	EList<Integer> getMoistureLevel();

	/**
	 * Returns the value of the '<em><b>Sections</b></em>' containment reference list.
	 * The list contents are of type {@link ims.Section}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sections</em>' containment reference list.
	 * @see ims.ImsPackage#getField_Sections()
	 * @model containment="true"
	 * @generated
	 */
	EList<Section> getSections();

} // Field
